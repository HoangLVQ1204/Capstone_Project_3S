
// lodash là thư viện chứa các FUNCTION giúp xử lí arrays, collections,... nhanh hơn
// so với thư viện có sẵn của Javascript.
// Mội số hàm thông dụng của lodash:
// - 
// - 
// -
var _ = require('lodash');

// Useful Tips:
// - Lodash: https://lodash.com/docs
// - Cách dùng Model trong Sequelize: http://sequelize.readthedocs.org/en/latest/docs/models-usage/
// - Cách dùng Instance trong Sequelize: http://sequelize.readthedocs.org/en/latest/docs/instances/
// - Promise trong Javascript: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise
// - Muốn sử dụng Express, cần phải hiểu Middleware và Router: http://fem-node-api.netlify.com/
module.exports = function(app) {    
    // Biến db có thể coi như một database. db.User chỉ đến bảng User, 
    // db.Post chỉ đến bảng Post
    // Trong Sequelize, Model là bảng. Instance là bản ghi. 
    // db.User là 1 Model, db.Post là 1 Model
    var db = app.get('models'); 

    // Hàm (middleware) này được gắn vào trong app.param 
    // và sẽ được chạy ĐẦU TIÊN đối với những URL có ":post_id"
    // Xem bên postRoutes.js

    // Ý nghĩa các tham số
    // - req: Đối tượng này chứa các thông tin của Request
    // - res: Đối tượng này chứa các thông tin của Response
    // - next: Là function (middleware) tiếp theo của middleware postIdParam
    // - post_id: chính là giá trị của ":post_id"
    var postIdParam = function(req, res, next, post_id) {        
        // Hàm findOne này tương tự câu lệnh SQL sau:
        // SELECT TOP 1 
        //    "PostId", "Title", "Content", "Created", "Modified", "CommentStatus", "Status", "UserId"
        // FROM "Post" WHERE "PostId" = post_id
        db.Post.findOne({
            attributes: ['PostId', 'Title', 'Content', 'Created', 'Modified', 'CommentStatus', 'Status', 'UserId'],
            where: {
                'PostId': post_id                
            }
        }).then(function(post) {        // Hàm then của Promise trong Javascript
            // Biến post là bản ghi lấy được từ câu lệnh SELECT
            // Biến post này chính là 1 Instance trong Sequelize            
            if (post) {
                // Gán bản ghi này vào req.post để sử dụng ở các middleware tiếp theo
                req.post = post;

                // Gọi đến middleware tiếp theo để xử lí URL trong request
                next();
            } else {
                // Nếu không tìm thầy bản ghi nào, thì gọi đến middleware dùng để xử lí lỗi
                next(new Error('No post with that id'));
            }
        }, function(err) {
            // Gọi đến middleware dùng để xử lí lỗi
            next(err);
        });
    };


    // GET /api/posts/total
    // >>> return INTEGER total number of posts
    // OUTPUT: total number of posts
    var getTotal = function(req, res, next) {        
        // Hàm count này tương tự SQL sau:
        // SELECT Count("PostId") FROM "Post" 
        // WHERE "UserId" = req.user.UserId
        db.Post.count({
            where: {
                // req.user chứa thông tin của user đã đăng nhập vào hệ thống
                // req.user được tạo ra trong middlewaressss checkUser (khai báo trong postRoutes.js)
                UserId: req.user.UserId                
            }
        })
        .then(function(c) {
            // Biến c là số lượng được trả về

            // PRO TIP: Nên sử dụng cách trả về res.status(HTTP_StatusCode).json(Object/Array..)
            // Với GET: res.status(200).json(....)
            // Với POST: res.status(201).json(....)
            // Với PUT: res.status(200).json(....)
            // Với DELETE: res.status(200).json(....)
            res.status(200).json(c);
        });       
    };


    // GET /api/posts/status/:status/total
    // >>> return INTEGER total number of posts of status
    // INPUT: status
    // OUTPUT: total number of posts of status
    var getTotalByStatus = function(req, res, next) {
        // Hàm count này tương tự SQL sau:
        // SELECT Count("PostId") FROM "Post" 
        // WHERE "UserId" = req.user.UserId AND "Status" = req.params.status
        db.Post.count({
            where: {
                UserId: req.user.UserId,

                // req.params là đối tượng chứa thông tin các tham số trong URL
                // Nếu URL của router có dạng /api/posts/:p1/:p2
                // Ví dụ URL = localhost:3000/api/posts/123/456
                // thì req.params.p1 = 123 và req.params.p2 = 456
                Status: req.params.status
            }
        })
        .then(function(c) {
            res.status(200).json(c);
        });
    };


    // GET /api/posts/page/:page_id?limit&sortByTitle&sortByDate
    // >>> return posts in page_id
    // INPUT: page_id
    // OUTPUT:
    // [ {
    //     PostId,
    //     Title,
    //     Part of Content,
    //     Created,
    //     Modified,
    //     Status    
    // } ]
    var getPostsInPage = function(req, res, next) {
        // req.query là đối tượng chứa thông tin các tham số trong URL
        // Ví dụ URL = localhost:3000/api/posts?p1=abc&p2=123
        // thì req.query.p1 = "abc" và req.query.p2 = 123
        var limit = req.query.limit;
        var offset = (req.params.page_id - 1) * limit;
        var orderTitle = 'ASC';
        if (req.query.sortByTitle) orderTitle = req.query.sortByTitle;
        var orderDate = 'DESC';
        if (req.query.sortByDate) orderDate = req.query.sortByDate;        

        // how to get part of content ???

        // Hàm findAll này tương ứng câu lệnh SQL sau:
        // SELECT OFFSET offset LIMIT limit 
        //     "PostId", "Title", "Content", "Created", "Modified", "CommentStatus", "Status"
        // FROM "Post" where "UserId" = req.user.UserId
        // ORDER BY "Title" ASC/DESC, "Created" ASC/DESC
        db.Post.findAll({
            offset: offset,
            limit: limit,
            where: {
                UserId: req.user.UserId                
            },
            order: [
                ['Title', orderTitle],  // orderTitle = ASC/DESC
                ['Created', orderDate]  // orderDate = ASC/DESC
            ],

            // các cột sẽ lấy ra
            attributes: ['PostId', 'Title', 'Content', 'Created', 'Modified', 'CommentStatus', 'Status']
        })
        .then(function(posts) {
            // posts là mảng các Instance (bản ghi) trả về
            res.status(200).json(posts);
        });
    };


    // GET /api/posts/:post_id
    // >>> return a post of post_id
    // INPUT: post_id
    // OUTPUT:
    // {
    //     PostId,
    //     Title,
    //     Full Content,
    //     Created,
    //     Modified,
    //     Status,
    //     CommentStatus,
    //     UserId
    // }
    var getOnePost = function(req, res, next) {
        // req.post là một đối tượng Instance (một bản ghi) trong Sequelize.
        // req.post sẽ chứa nhiều phương thức và thuộc tính khác nhau. 
        // Dùng console.log(req.post) để biết
        // req.post.toJSON() sẽ trả về một đối tượng chỉ chứa 
        // các thuộc tính là giá trị của các cột
        res.status(200).json(req.post.toJSON());
    };


    // POST /api/posts
    // >>> add a new post
    // INPUT:
    // {
    //     Title,
    //     Content,
    //     Created,
    //     Modified,
    //     [ Categories ],
    //     Status,
    //     CommentStatus
    // }
    // OUTPUT:
    // {
    //     PostId,
    //     [ CategoryId ]
    // }
    var post = function(req, res, next) {
        // _.cloneDeep(inputObject) sẽ trả về một đối tượng 
        // chứa đầy đủ các thuộc tính giống hệt inputObject
        var newPost = _.cloneDeep(req.body);
        newPost.UserId = req.user.UserId;        
        delete newPost.Categories;               

        // Hàm build này dùng để chèn một bản ghi mới trong database 
        // có các giá trị của cột tương ứng với thuộc tính trong newPost
        // tương ứng câu lệnh SQL sau:
        // INSERT INTO "Post" (tên các cột = tên các thuộc tính) 
        // VALUES (giá trị các cột = giá trị các thuộc tính)
        db.Post.build(newPost)
        .save()

        // Ý nghĩa của function này:
        // - Đầu tiên chèn 1 bản ghi vào bảng Post
        // - Sau đó chèn các bản ghi vào bảng Categories
        // - Sau đó chèn các bản ghi vào bảng PostCategories
        .then(function(post) {
            // Biến post là Instance (bản ghi) được tạo ra

            // req.body là đối tượng tương ứng phần body của request
            var categories = req.body.Categories;
            categories = categories.map(function(category) {
                // Hàm findOrCreate tương tự hàm findOne, 
                // khác ở chỗ nếu không tìm thấy bản ghi nào, 
                // nó sẽ tự tạo một bản ghi có giá trị của "defaults"
                return db.Category.findOrCreate({
                    where: {
                        CategoryName: category
                    },
                    defaults: {
                        CategoryName: category
                    }
                })
                .spread(function(category, created) {   // hàm spread của Promise, tương tự hàm then
                    // Biến category là đối tượng Instance được tạo ra / trả về
                    // Biến created = true thì chứng tỏ không tìm thấy vào một bản ghi được tạo mới
                    // created = false thì ngược lại
                    return category.CategoryId;
                }, function(err) {
                    next(err);
                })
            });    

            Promise.all(categories)
            .then(function(data) {            
                var post_category = data.map(function(categoryId) {
                    return db.PostCategory.build({
                        PostId: post.PostId,
                        CategoryId: categoryId
                    })
                    .save()
                    .then(function(post_category) {                        
                        return post_category;
                    }, function(err) {                        
                        next(err);
                    });
                });

                Promise.all(post_category)
                .then(function(items) {
                    res.status(201).json({
                        PostId: post.PostId,
                        CategoryId: data
                    });
                }, function(err) {
                    next(err);
                });
            }, function(err) {
                next(err);
            });
        }, function(err) {
            next(err);
        });        
    };


    // PUT /api/posts/:post_id
    // >>> modify a post with post_id
    // INPUT: 
    // post_id
    // {
    //     Title,
    //     Content,
    //     Modified,
    //     Categories,
    //     Status,
    //     CommentStatus
    // }
    // OUTPUT:
    // {
    //     PostId,
    //     [ CategoryId ]
    // }
    var put = function(req, res, next) {
        var newPost = _.cloneDeep(req.body);
        newPost.UserId = req.user.UserId;        
        delete newPost.Categories;               

        var curPost = req.post;

        // _.merge thêm và ghi đè các thuộc tính của đối tượng newPost vào đối tượng curPost
        _.merge(curPost, newPost);        
        
        // Hàm save này gọi từ Instance dùng để 
        // cập nhật giá trị của 1 bản ghi trong bảng Post        
        curPost.save()
        .then(function(post) {
            var categories = req.body.Categories;
            categories = categories.map(function(category) {
                return db.Category.findOrCreate({
                    where: {
                        CategoryName: category
                    },
                    defaults: {
                        CategoryName: category
                    }
                })
                .spread(function(category, created) {
                    return {
                        CategoryId: category.CategoryId,
                        created: created
                    };
                }, function(err) {
                    next(err);
                })
            });

            Promise.all(categories)
            .then(function(data) {         
                var post_category = data.map(function(item) {
                    if (item.created) {
                        return db.PostCategory.build({
                            PostId: post.PostId,
                            CategoryId: item.CategoryId
                        })
                        .save()
                        .then(function(post_category) {                        
                            return post_category;
                        }, function(err) {                        
                            next(err);
                        });
                    } else {
                        return null;
                    }              
                });

                Promise.all(post_category)
                .then(function(items) {
                    data = data.map(function(item) {
                        return item.CategoryId;
                    });
                    res.status(201).json({
                        PostId: post.PostId,
                        CategoryId: data
                    });
                }, function(err) {
                    next(err);
                });
            }, function(err) {
                next(err);
            });
        }, function(err) {
            next(err);
        });        
    };


    // DELETE /api/posts/:post_id
    // >>> delete a post with post_id
    // INPUT: post_id
    // OUTPUT:
    // {
    //     PostId
    // }
    var deleteOnePost = function(req, res, next) {
        // Hàm destroy tương đương câu lệnh SQL sau:
        // DELETE FROM "PostCategory" WHERE "PostId" = req.post.PostId
        db.PostCategory.destroy({
            where: {
                PostId: req.post.PostId
            }
        })
        .then(function(deleted) {
            // Cũng tương tự DELETE trong SQL
            // khác ở chỗ truyền vào thuộc tính force: true, 
            // tức là sau khi xóa trong database thì KHÔNG THỂ khôi phục lại được
            req.post.destroy({ force: true })
            .then(function() {
                res.status(200).json(req.post.PostId);
            }, function(err) {
                next(err);
            });
        }, function(err) {
            next(err);
        });       
    };


    // DELETE /api/posts/delete
    // >>> delete multiple posts in array of post_id
    // INPUT: [ post_id ]
    // OUTPUT:
    // {
    //     Number of posts deleted  
    // }
    var deleteMultiple = function(req, res, next) {
        var posts = req.body;
        posts = posts.map(function(postId) {
            return db.PostCategory.destroy({
                where: {
                    PostId: postId
                }
            })
            .then(function(deleted) {
                db.Post.destroy({ 
                    where: {
                        PostId: postId
                    }
                })
                .then(function() {
                    return postId;
                }, function(err) {
                    next(err);
                });
            }, function(err) {
                next(err);
            });
        });   
        Promise.all(posts)
        .then(function(data) {
            res.status(200).json(data.length);
        });
    };

    return {
        getTotal: getTotal,
        getTotalByStatus: getTotalByStatus,
        getPostsInPage: getPostsInPage,
        postIdParam: postIdParam,
        getOnePost: getOnePost,
        post: post,
        put: put,
        deleteOnePost: deleteOnePost,
        deleteMultiple: deleteMultiple
    };
    
}

// TODO: Implement Post API

/*

NOTEEEE: GET posts based on UserId


GET /api/posts/total
>>> return INTEGER total number of posts
OUTPUT: total number of posts


GET /api/posts/status/:status/total
>>> return INTEGER total number of posts of status
INPUT: status
OUTPUT: total number of posts of status


GET /api/posts/page/:page_id?limit&sortByTitle&sortByDate
>>> return posts in page_id
INPUT: page_id
OUTPUT:
[ {
    PostId,
    Title,
    Part of Content,
    Created,
    Modified,
    Status,
    CommentStatus
} ]


GET /api/posts/:post_id
>>> return a post of post_id
INPUT: post_id
OUTPUT:
{
    PostId,
    Title,
    Full Content,
    Created,
    Modified,
    Status,
    CommentStatus,
    UserId
}


GET /api/posts/status/:status/page/:page_id?limit&sortByTitle&sortByDate
>>> return posts of a status in page_id
INPUT: status, page_id
OUTPUT:
[ {
    PostId,
    Title,
    Part of Content,
    Created,
    Modified,
    Status
} ]


GET /api/posts/category/:category_id/page/:page_id
>>> return posts of category_id in page_id
INPUT: category_id, page_id
OUTPUT:
[ {
    PostId,
    Title,
    Part of Content,
    Created,
    Modified,
    Status,
    CommentStatus
} ]


GET /api/posts/category/:category_id/status/:status/page/:page_id?limit&sortByTitle&sortByDate
>>> return posts of category_id in page_id
INPUT: category_id, page_id
OUTPUT:
[ {
    PostId,
    Title,
    Part of Content,
    Created,
    Modified,
    Status
} ]


POST /api/posts
>>> add a new post
INPUT:
{
    Title,
    Content,
    Created,
    Modified,
    [ Categories ],
    Status,
    CommentStatus
}
OUTPUT:
{
    PostId,
    [ CategoryId ]
}


PUT /api/posts/:post_id
>>> modify a post with post_id
INPUT: 
post_id
{
    Title,
    Content,
    Modified,
    Categories,
    Status,
    CommentStatus
}
OUTPUT:
{
    PostId,
    [ CategoryId ]
}


DELETE /api/posts/:post_id
>>> delete a post with post_id
INPUT: post_id
OUTPUT:
{
    PostId
}


DELETE /api/posts/delete
>>> delete multiple posts in array of post_id
INPUT: [ post_id ]
OUTPUT:
{
    Number of posts deleted  
}

*/