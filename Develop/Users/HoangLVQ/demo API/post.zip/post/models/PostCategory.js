/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var PostCategory = sequelize.define('PostCategory', { 
    PostId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    CategoryId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    }
  }, {
      freezeTableName: true,
      timestamps: false      
  });
  PostCategory.removeAttribute('id');
  return PostCategory;
};
