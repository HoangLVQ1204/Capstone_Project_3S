

module.exports = function(app){
 	var controller = require('./postController')(app);
 	var authentication = require('../../auth/authentication')(app);
 	var checkUser = [authentication.decodeToken(), authentication.getFreshUser()];
 	
 	app.param('post_id', controller.postIdParam);

 	app.get('/api/posts/total', checkUser, controller.getTotal);
 	app.get('/api/posts/status/:status/total', checkUser, controller.getTotalByStatus);
 	app.get('/api/posts/page/:page_id', checkUser, controller.getPostsInPage);
 	app.get('/api/posts/:post_id', checkUser, controller.getOnePost);

 	app.post('/api/posts', checkUser, controller.post);
 	app.put('/api/posts/:post_id', checkUser, controller.put);
 	app.delete('/api/posts/delete', checkUser, controller.deleteMultiple);
 	app.delete('/api/posts/:post_id', checkUser, controller.deleteOnePost); 	
}