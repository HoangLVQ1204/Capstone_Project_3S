/**
 * Created by hoanglvq on 9/22/15.
 */

function AppController($state, authService){
    var checkType =
    authService.userIsLoggedIn(function(role){
        if(role.isAdmin){
            $state.go('app.admin');
        }else if(role.isStore){
            $state.go('app.store');
        }else{
            $state.go('app.guest');
        }
    });
}
AppController.$inject = ['$state','authService'];
module.exports = AppController;