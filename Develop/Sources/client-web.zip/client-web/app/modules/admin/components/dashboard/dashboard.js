//var angular = require('angular');
//var aboutDirective = require('./dashboard.directive.js');
//
//module.exports = angular.module('guest.about',[])
//    .directive('guestAbout',aboutDirective);