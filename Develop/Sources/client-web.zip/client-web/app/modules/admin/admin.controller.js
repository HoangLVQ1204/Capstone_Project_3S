/**
 * Created by hoanglvq on 9/22/15.
 */
console.log('AdminController');
function AdminController($state) {
    this.title = 'This is Admin Page';
}

AdminController.$inject = ['$state'];

module.exports = AdminController;